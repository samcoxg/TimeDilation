let express = require('express');
let app = express();
let path = require('path');
let bodyParser = require('body-parser');
let knex = require('knex')({
    client: 'sqlite3',
    connection: {
        filename: "./captcha.db"
    },
    useNullAsDefault: true
});

app.use(bodyParser.urlencoded({
    extended: true
}));
app.set('view engine', 'ejs');

app.get('/database', (req, res) =>
    knex.select('userID', 'allA', 'allC', 'labelA', 'labelC', 'findWrongA', 'findWrongC', 'findImageA', 'findImageC',
     'typeWordsA', 'typeWordsC','findPatternA', 'findPatternC', 'wrongWordA', 'wrongWordC', 'avgResTime', 'timeEstimate', 'timeFeel',
     'lever', 'hurry', 'awareness', 'distraction', 'motivation', 'boring', 'repetitive', 'pressure', 'educationLevel', 'emotion', 'gender', 'age').from('Main')
    .orderBy('userID').then(mainRec => {
        res.render('index', {
            mainData: mainRec
        })
    })
);

app.use(express.static(path.join(__dirname, 'capTests')));


app.post('/DeleteMain/:id', (req, res) => {
    knex('Main').where('userID', req.params.id).del().then(mainRec => {
        res.redirect("/database");
    }).catch(err => {
        console.log(err);
        res.status(500).json({
            err
        });
    });
});

app.get('/', (req, res) => {
    knex.select('userID').from('Main').orderBy('userID', 'desc').then(mainRec => {
        res.render('startPage', {
            mainData: mainRec
        })
    })
});

app.get('/thankyou', (req, res) => {
        res.render('thankyou', {
        })
    });

app.get('/addMain', (req, res) => {
    knex.select('userID').from('Main').orderBy('userID', 'desc').then(mainRec => {
        res.render('addMain', {
            mainData: mainRec
        })
    })
});


app.post('/captchaStart', (req, res) => {
    knex('Main').insert(req.body/*
        [{
            allC: req.body.v2,
            labelA: req.body.v3,
            labelC: req.body.v4, 
            findWrongA: req.body.v5, 
            findWrongC: req.body.v6,
            findImageA: req.body.v7, 
            findImageC: req.body.v8,
            typeWordsA: req.body.v9, 
            typeWordsC: req.body.v10,
            findPatternA: req.body.v11, 
            findPatternC: req.body.v12, 
            wrongWordA: req.body.v13, 
            wrongWordC: req.body.v14, 
            avgResTime: req.body.v15,
            timeEstimate: req.body.timeEstimate, 
            timeFeel: req.body.timeFeel,
            lever: req.body.v16,
            hurry: req.body.hurry, 
            awareness: req.body.awareness, 
            distraction: req.body.distraction, 
            motivation: req.body.motivation, 
            rewarding: req.body.rewarding, 
            boring: req.body.boring, 
            repetitive: req.body.repetitive, 
            pressure: req.body.pressure, 
            educationLevel: req.body.educationLevel, 
            emotion: req.body.emotion, 
            gender: req.body.gender, 
            age: req.body.age
            },
        ]*/
    ).then(main => {
        res.redirect('/addMain');
    });
});

app.get('/UpdateMain/:id', (req, res) => {
    knex.select("*").from('Main').where('userID', req.params.id).then(mainRec => {
        res.render("UpdateMain", {
            mainData: mainRec
        });
    });
});


app.post('/UpdateMain/:id', (req, res) => {
    knex('Main').where('userID', req.params.id).update(req.body).then(mainData => {
        res.redirect("/thankyou");
    });
});



app.listen(3000, () => console.log("Server running."));