

var Questions = [
    [1, "Select the word that best describes this image. <br><br><img src='images/label_image/1.jpg' style='height:300px;'>", "a", "frog", "lizard", "cat", "camelion", 1],
    [2, "Select the word that best describes this image. <br><br><img src='images/label_image/2.jpg' style='height:300px;'>", "b", "truck", "car", "train", "bus", 1],
    [3, "Select the word that best describes this image. <br><br><img src='images/label_image/3.jpg' style='height:300px;'>", "c", "phone", "tablet", "laptop", "box", 1],
    [4, "Select the word that best describes this image. <br><br><img src='images/label_image/4.jpg' style='height:300px;'>", "d", "music", "dinner", "plane", "hike", 1],
    [5, "Select the word that best describes this image. <br><br><img src='images/label_image/5.jpg' style='height:300px;'>", "a", "space", "earth", "water", "paint", 1],
    [6, "Select the word that best describes this image. <br><br><img src='images/label_image/6.jpg' style='height:300px;'>", "b", "chair", "couch", "recliner", "bed", 1],
    [7, "Select the word that best describes this image. <br><br><img src='images/label_image/7.jpg' style='height:300px;'>", "c", "soccer", "baseball", "football", "tag", 1],
    [8, "Select the word that best describes this image. <br><br><img src='images/label_image/8.jpg' style='height:300px;'>", "d", "brick", "tower", "island", "skyscrapers", 1],
    [9, "Select the word that best describes this image. <br><br><img src='images/label_image/9.jpg' style='height:300px;'>", "a", "earth", "sun", "saturn", "pluto", 1],
    [10, "Select the word that best describes this image. <br><br><img src='images/label_image/10.jpg' style='height:300px;'>", "b", "texas", "beach", "shark", "fish", 1],
    [11, "Select the word that best describes this image. <br><br><img src='images/label_image/11.jpg' style='height:300px;'>", "c", "ice", "water", "lemonade", "glass", 1],
    [12, "Select the word that best describes this image. <br><br><img src='images/label_image/12.jpg' style='height:300px;'>", "d", "log", "green", "mountain", "bird", 1],
    [13, "Select the word that best describes this image. <br><br><img src='images/label_image/13.jpg' style='height:300px;'>", "b", "landscape", "television", "clouds", "pixels", 1],
    [14, "Select the word that best describes this image. <br><br><img src='images/label_image/14.jpg' style='height:300px;'>", "c", "violin", "drums", "trumpet", "piano", 1],
    [15, "Select the word that best describes this image. <br><br><img src='images/label_image/15.jpg' style='height:300px;'>", "d", "sunflower", "bird", "gnat", "tree", 1],
    [16, "Which of the following images does not belong?", 'images/wrongImage/1.1.jpg', 'images/wrongImage/1.2.jpg', 'images/wrongImage/2.1.jpg', 'images/wrongImage/1.3.jpg', "c", "first image", "second image", "third image", "fourth image", 2],
    [17, "Which of the following images does not belong?", 'images/wrongImage/3.1.jpg', 'images/wrongImage/3.2.jpg', 'images/wrongImage/3.3.jpg', 'images/wrongImage/4.1.jpg', "d", "first image", "second image", "third image", "fourth image", 2],
    [18, "Which of the following images does not belong?", 'images/wrongImage/2.4.jpg', 'images/wrongImage/4.2.jpg', 'images/wrongImage/4.1.jpg', 'images/wrongImage/4.3.jpg', "a", "first image", "second image", "third image", "fourth image", 2],
    [19, "Which of the following images does not belong?", 'images/wrongImage/1.4.jpg', 'images/wrongImage/2.4.jpg', 'images/wrongImage/2.3.jpg', 'images/wrongImage/2.2.jpg', "a", "first image", "second image", "third image", "fourth image", 2],
    [20, "Choose the word that belongs with the following: <br> apple, banana, orange... ", "a", "grape", "carrot", "pickle", "potatoe", 5],
    [21, "Choose the word that belongs with the following: <br> hiking, kayaking, repelling... ", "b", "sharing", "backpacking", "driving", "eating", 5],
    [22, "Choose the word that belongs with the following: <br> toaster, fridge, oven... ", "c", "knife", "painting", "stove", "couch", 5],
    [23, "Choose the word that belongs with the following: <br> mother, brother, sister... ", "d", "employee", "affiliate", "friend", "father", 5],
    [24, "Choose the word that belongs with the following: <br>socks, shirt, pants...", "a", "shoes", "computer", "glasses", "gloves", 5],
    [25, "Type out the numbers and letters in the image below. Lowercase and no spaces! <br><br><img src='images/typeWords/1.jpg' style='width:200px;'>", "28ivw", 3],
    [26, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/2.jpg' style='width:200px;'>", "k4ez", 3],
    [27, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/3.jpg' style='width:200px;'>", "jw62k", 3],
    [28, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/4.jpg' style='width:200px;'>", "fh2de", 3],
    [29, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/5.jpg' style='width:200px;'>", "q98p", 3],
    [30, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/6.jpg' style='width:200px;'>", "annoyanceoct", 3],
    [31, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/7.jpg' style='width:200px;'>", "overlooksinquiry", 3],
    [32, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/8.jpg' style='width:200px;'>", "nrtgdkwn", 3],
    [33, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/9.jpg' style='width:200px;'>", "frupereog", 3],
    [34, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/10.jpg' style='width:200px;'>", "r6hodfq", 3],
    [35, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/11.jpg' style='width:200px;'>", "", 3],
    [36, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/12.jpg' style='width:200px;'>", "", 3],
    [37, "Type out the numbers and letters in the image below. Lowercase and no spaces!  <br><br><img src='images/typeWords/13.jpg' style='width:200px;'>", "", 3],
    [38, "Which of the following images contains a dog?", 'images/dogs/21.jpg','images/dogs/20.jpg','images/dogs/1.jpg','images/dogs/16.jpg', "c", "first image", "second image", "third image", "fourth image", 4],
    [39, "Which of the following images contains a dog?", 'images/dogs/9.jpg','images/dogs/2.jpg','images/dogs/10.jpg','images/dogs/11.jpg', "b", "first image", "second image", "third image", "fourth image", 4],
    [40, "Which of the following images contains a dog?", 'images/dogs/3.jpg','images/dogs/15.jpg','images/dogs/14.jpg','images/dogs/13.jpg', "a", "first image", "second image", "third image", "fourth image", 4],
    [41, "Which of the following images contains a dog?", 'images/dogs/12.jpg','images/dogs/21.jpg','images/dogs/9.jpg','images/dogs/4.jpg', "d", "first image", "second image", "third image", "fourth image", 4],
    [42, "Finish the following pattern: <br> 3, 6, 9, 12...", "c", "16", "11", "15", "18", 5],
    [43, "Finish the following pattern: <br> 2, 4, 3, 5, 4...", "a", "6", "8", "2", "3", 5],
    [44, "Finish the following pattern: <br> 10, 20, 40, 80...", "b", "90", "160", "100", "120", 5],
    [45, "Finish the following pattern: <br> Spring: rain, Winter: snow, Summer:", "c", "fall", "leaves", "sun", "christmas", 5],
    [46, "Finish the following pattern: <br> 80, 40, 20, 10...", "d", "20", "2", "0", "5", 5],
    [47, "Choose the option that does NOT belong.", "a", "chicken", "banana", "apple", "orange", 6],
    [48, "Choose the option that does NOT belong.", "b", "sparrow", "moose", "hawk", "eagle", 6],
    [49, "Choose the option that does NOT belong.", "c", "train", "car", "piano", "bus", 6],
    [50, "Choose the option that does NOT belong.", "d", "ski", "snowboard", "snowshoe", "volcano", 6],
    [51, "Which of the following images contains a bike?", 'images/dogs/13.jpg', 'images/dogs/11.jpg', 'images/dogs/12.jpg', 'images/dogs/10.jpg', "a", "first image", "second image", "third image", "fourth image", 4],
    [52, "Which of the following images contains a bike?", 'images/dogs/18.jpg', 'images/bikes/bike1.jpg', 'images/dogs/17.jpg', 'images/dogs/16.jpg', "b", "first image", "second image", "third image", "fourth image", 4],
    [53, "Which of the following images contains a bike?", 'images/dogs/3.jpg', 'images/dogs/15.jpg', 'images/bikes/bike2.jpg', 'images/dogs/5.jpg', "c", "first image", "second image", "third image", "fourth image", 4],
    [54, "Which of the following images contains a bike?", 'images/dogs/12.jpg', 'images/dogs/21.jpg', 'images/dogs/17.jpg', 'images/bikes/bike3.jpg', "d", "first image", "second image", "third image", "fourth image", 4],
    [55, "Which of the following images contains fruit?", 'images/dogs/18.jpg', 'images/dogs/12.jpg', 'images/dogs/17.jpg', 'images/dogs/16.jpg', "b", "first image", "second image", "third image", "fourth image", 4],
    [56, "Which of the following images contains fruit?", 'images/dogs/18.jpg', 'images/fruit/fruit1.jpg', 'images/dogs/17.jpg', 'images/dogs/16.jpg', "b", "first image", "second image", "third image", "fourth image", 4],
    [57, "Which of the following images contains fruit?", 'images/dogs/3.jpg', 'images/dogs/15.jpg', 'images/fruit/fruit2.jpg', 'images/dogs/13.jpg', "c", "first image", "second image", "third image", "fourth image", 4],
    [58, "Which of the following images contains fruit?", 'images/wrongImage/1.1.jpg', 'images/wrongImage/2.1.jpg', 'images/wrongImage/3.1.jpg', 'images/fruit/fruit3.jpg', "d", "first image", "second image", "third image", "fourth image", 4],
    [59, "Select the word that best describes this image. <br><br><img src='images/label_image/16.jpg' style='height:300px;'>", "a", "turtle", "fish", "crab", "lobster", 1],
    [60, "Select the word that best describes this image. <br><br><img src='images/label_image/17.jpg' style='height:300px;'>", "b", "dinner", "cookie", "plate", "accuracy", 1],
    [61, "Select the word that best describes this image. <br><br><img src='images/label_image/18.jpg' style='height:300px;'>", "c", "fish", "pet", "shark", "friendly", 1],
    [62, "Select the word that best describes this image. <br><br><img src='images/label_image/19.jpg' style='height:300px;'>", "c", "draw", "table", "bed", "evening", 1],
    [63, "Select the word that best describes this image. <br><br><img src='images/label_image/20.jpg' style='height:300px;'>", "d", "toothpick", "sharpener", "pen", "pencil", 1],
    [64, "Choose the option that describes the others.", "a", "country", "Japan", "Mexico", "Canada", 6],
    [65, "Choose the option that describes the others.", "b", "sparrow", "bird", "falcon", "finch", 6],
    [66, "Choose the option that describes the others.", "c", "spoon", "fork", "utinsel", "knife", 6],
    [67, "Choose the option that describes the others.", "d", "windy", "rainy", "snowy", "weather", 6],
    [68, "Finish the following pattern: <br>   blue, red, orange, blue... ", "a", "red", "blue", "orange", "brown", 5],
    [69, "Finish the following pattern: <br>   12, 21, 13, 31, 14... ", "b", "15", "41", "14", "4.1", 5],
    [70, "Finish the following pattern: <br>   10, 20, 40, 80... ", "b", "90", "160", "100", "120", 5],
    [71, "Finish the following pattern: <br>   Spring: rain, Winter: snow, Summer: ", "c", "fall", "leaves", "sun", "christmas", 5],
    [72, "Finish the following pattern: <br>   80, 40, 20, 10... ", "d", "20", "2", "0", "5", 5],
    [73, "Choose the option that does NOT belong.", "a", "pillow", "river", "tree", "log", 6],
    [74, "Choose the option that does NOT belong.", "b", "toaster", "iPhone", "waffle", "hashbrowns", 6],
    [75, "Choose the option that does NOT belong.", "c", "shoe", "sock", "pepper", "boot", 6],
    [76, "Choose the option that does NOT belong.", "d", "schools", "classes", "teachers", "penguins", 6],
    [77, "Choose the option that describes the others.", "a", "color", "red", "blue", "brown", 6],
    [78, "Choose the option that describes the others.", "b", "aunt", "relative", "uncle", "cousin", 6],
    [79, "Choose the option that describes the others.", "c", "january", "august", "month", "july", 6],
    [80, "Choose the option that describes the others.", "d", "tuesday", "sunday", "monday", "day", 6]
    
];
let instructions = undefined;
let iWhile = 0;
let correctAnswer = undefined;
var labelI = [0,0];
var find_wrongI = [0,0];
var findDog = [0,0];
var typeWords = [0,0];
var findPattern = [0,0];
var findWrongWord = [0,0];
var totalAnswers = [0,0];
var inputType = undefined;
let leverType = undefined;
let storeUID = undefined;
let imageChoice = undefined;
let userID = undefined;
let rNumRepeat = false;

displayLever();
function getQuestion()
{
    //random number and loops to eliminate repetition
    let numFound = false; 
    let rNum = 0;

    while (numFound == false)
    {
        if(iWhile < Questions.length)
        {
            if(rNumRepeat == true)
            {
                rNum++;
            }
            else
            {
                rNum = Math.floor(Math.random()*Questions.length)+1;
            }
            //rNum = 51;
            for(let iCount=0; iCount<Questions.length; iCount++)
            {
                if(rNum == Questions[iCount][0])
                {   
                    correctAnswer = Questions[iCount][2];
                    
                    if(Questions[iCount][3] == 3)
                    {
                        inputType = Questions[iCount][3];
                        instructions = "<h3 style='font-size:1.4em'>" + Questions[iCount][1]
                            + "</h3><br><input type='text' name='answer' id='text1' autofocus> <br><input type='button' value='Submit' id='checkAcc' onClick='checkAcc()' >";
                        Questions[iCount][0]= 0;
                        numFound = true;
                        iWhile++;
                    }
                    
                    else if(Questions[iCount][11] == 4 || Questions[iCount][11] == 2)
                    {
                        correctAnswer = Questions[iCount][6];
                        inputType = Questions[iCount][11];
                        instructions = "<h3 style='font-size:1.4em'>" + Questions[iCount][1] 
                        + "</h3><br><br><label><input type='radio' id='a1' value='a' class='radioImage'/> <img src='" + Questions[iCount][2] +"' style='object-fit:cover; width:300px;'></label>"  
                        + "<label><input type='radio' id='a2' value='b'class='radioImage'/> <img src='" + Questions[iCount][3] +"' style='object-fit:cover; width:300px;'></label>"
                        + "<label><input type='radio' id='a3' value='c'class='radioImage'/> <img src='" + Questions[iCount][4] +"' style='object-fit:cover; width:300px;'></label>"
                        + "<label><input type='radio' id='a4' value='d'class='radioImage'/> <img src='" + Questions[iCount][5] +"' style='object-fit:cover; width:300px;'></label><input type='button' value='Submit' id='checkAcc' onClick='checkAcc()'>";
                        Questions[iCount][0] = 0;
                        numFound = true;
                        iWhile++;
                    }
                    
                    else
                    {
                        inputType = Questions[iCount][7];
                        instructions = "<h3 style='font-size:1.4em'>" + Questions[iCount][1] 
                            + "</h3><br><input type='radio' name='answer' id='a1' value='a'> "
                            + Questions[iCount][3]
                            + "<br><input type='radio' name='answer' id='a2' value='b'> "
                            + Questions[iCount][4]
                            + "<br><input type='radio' name='answer' id='a3' value='c'> "
                            + Questions[iCount][5]
                            + "<br><input type='radio' name='answer' id='a4' value='d'> "
                            + Questions[iCount][6]
                            + "<br><br><input type='button' value='Submit' id='checkAcc' onClick='checkAcc()'>";
                        Questions[iCount][0]= 0;
                        numFound = true;
                        iWhile++;
                    }  
                }
            }
        }
        else
        {
            numFound = true;
            instructions = "Out of questions"
        }
    }   
}

function displayLever()
{
    userID = document.getElementById("storeUID").innerHTML;
    //no changes, control group
    if(userID[userID.length -1] == 1)
    {
        document.getElementById("mainStyle").style.backgroundColor="white";
        document.body.style.backgroundColor = "white";
        document.body.style.color="black";
    }
    //dark mode
    else if(userID[userID.length -1] == 2)
    {
        document.getElementById("mainStyle").style.backgroundColor="#242323";
        document.body.style.backgroundColor = "#242323";
        document.body.style.color="white";
        //document.getElementsByTagName("strong").style.color = "white";
    }
    //warm color
    else if(userID[userID.length -1] == 3)
    {
        document.getElementById("mainStyle").style.backgroundColor="#ffbcb5";
        document.body.style.backgroundColor = "#ffbcb5";
        document.body.style.color="black";
    }
    //cool color
    else if(userID[userID.length -1] == 4)
    {
        document.getElementById("mainStyle").style.backgroundColor="#b5deff";
        document.body.style.backgroundColor = "#b5deff";
        document.body.style.color="black";
    }
    //music selection --positive
    else if(userID[userID.length -1] == 5)
    {
        //please select the music genre you would most likely enjoy
        //based on user response, start playing happy music of selected genre
    }
    //music selection --negative
    else if(userID[userID.length -1] == 6)
    {
        //please select the music genre you would most likely enjoy
        //based on user response, start playing sad music of selected genre
    }
    //repetetive
    else if(userID[userID.length -1] == 7)
    {
        rNumRepeat = true;
    }
    //high cognitive engagement in a positive state
    else if(userID[userID.length -1] == 8)
    {
        //
    }
    //
    else if(userID[userID.length -1] == 9)
    {
        //
    }
    else if(userID[userID.length -1] == 10)
    {
        //
    }
    displayCap();
}


function displayCap()
{
    //let iDisplay = Math.floor(Math.random()*6);
    let iDisplay = 3;
    window.scrollTo(0, 0);
    getQuestion();
    document.getElementById("title").innerHTML = instructions;
    document.getElementById("cap").className = "cap";

  //7 minutes timer
    let start = Date.now(); // The current date (in miliseconds)
    let end = start + 120000; // 2 minutes = 420,000

    function spinWheel() 
    {
        start = Date.now(); // Get the date currently
        if(start > end)
        {
            let avgResponse = (420/(totalAnswers[0]));
            clearInterval(timer); // If we are 5 seconds later clear interval
            document.getElementById("allA").value = totalAnswers[0];
            document.getElementById("cap").style.width = "80%";
            //document.forms[0].fid_17.value = totalAnswers[0];
            document.getElementById("allC").value = totalAnswers[1];
            document.getElementById("labelA").value = labelI[0];
            document.getElementById("labelC").value = labelI[1];
            document.getElementById("findWrongA").value = find_wrongI[0];
            document.getElementById("findWrongC").value = find_wrongI[1];
            document.getElementById("findImageA").value = findDog[0];
            document.getElementById("findImageC").value = findDog[1];
            document.getElementById("typeWordsA").value = typeWords[0];
            document.getElementById("typeWordsC").value = typeWords[1];
            document.getElementById("findPatternA").value = findPattern[0];
            document.getElementById("findPatternC").value = findPattern[1];
            document.getElementById("wrongWordA").value = findWrongWord[0];
            document.getElementById("wrongWordC").value = findWrongWord[1];
            document.getElementById("lever").value = avgResponse;//7 minutes divided by total responses
            displaySurvey();
        } 
    }
    let timer = setInterval(spinWheel, 100);
    
}

function displaySurvey()
{
    document.getElementById("title").innerHTML = "Time has run out. Please complete the following survey regarding your experience.";
    document.getElementById("survey1").style.display = "initial";
    document.getElementById("mainStyle").style.backgroundColor = "white";
    document.getElementById("mainStyle").style.color = "#6b6b6b";
}

function checkAcc()
{
    let answerSelected = undefined;
    if(inputType == 3)
    {
        let answerTyped = document.getElementById("text1").value;
        answerTyped = answerTyped.toLowerCase();
        if(answerTyped == correctAnswer)
        {
            answerSelected = true;
        }
        else
        {
            answerSelected = false;
        }
    }
    
    else
    {
        for(let iCount = 0; iCount < 4; iCount++)
        {
            let checkSelect = document.getElementById("a" + (iCount + 1));
            if (checkSelect.checked == true && checkSelect.value == correctAnswer)
            {
                answerSelected = true;
            }
            else if(checkSelect.checked == true && checkSelect.value != correctAnswer)
            {
                answerSelected = false;
            }
            else
            {
                let i = 0;
            }
        }
    }
    

        if(answerSelected == true)
        {
            totalAnswers[0] = totalAnswers[0] + 1;
            totalAnswers[1] = totalAnswers[1] + 1;
            if(inputType == 1)
            {
                labelI[0] = labelI[0] + 1;
                labelI[1] = labelI[1] + 1;
            }
            else if(inputType == 2)
            {
                find_wrongI[0] = find_wrongI[0] + 1;
                find_wrongI[1] = find_wrongI[1] + 1;
            }
            else if(inputType == 3)
            {
                typeWords[0] = typeWords[0] + 1;
                typeWords[1] = typeWords[1] + 1;
            }
            else if(inputType == 4)
            {
                findDog[0] = findDog[0] + 1;
                findDog[1] = findDog[1] + 1;
            }
            else if(inputType == 5)
            {
                findPattern[0] = findPattern[0] + 1;
                findPattern[1] = findPattern[1] + 1;
            }
            else
            {
                findWrongWord[0] = findWrongWord[0] + 1;
                findWrongWord[1] = findWrongWord[1] + 1;
            }
    
        }
        else
        {
            totalAnswers[0] = totalAnswers[0] + 1;
            if(inputType == 1)
            {
                labelI[0] = labelI[0] + 1;
            }
            else if(inputType == 2)
            {
                find_wrongI[0] = find_wrongI[0] + 1;
            }
            else if(inputType == 3)
            {
                typeWords[0] = typeWords[0] + 1;
            }
            else if(inputType == 4)
            {
                findDog[0] = findDog[0] + 1;
            }
            else if(inputType == 5)
            {
                findPattern[0] = findPattern[0] + 1;
            }
            else
            {
                findWrongWord[0] = findWrongWord[0] + 1;
            }
    
          qCorrect = 0;  
        }
    displayCap();
}